import os
import re
import json
from tkinter import Tk, Label, Button, Text, Scrollbar, Entry, END, Frame, filedialog, BOTH, RIGHT, Y, LEFT, X, BOTTOM

# Allowed Keys
ALLOWED_KEYS = [
    "db.this", "db.user", "db.host", "APP.IDM_EMULATOR_SERVICE",
    ".connectionurl", "dsidentityverification.connectionurl"
]

def key_is_allowed(key):
    return any(key == allowed or key.startswith(allowed) for allowed in ALLOWED_KEYS)

def browse_folder():
    folder_selected = filedialog.askdirectory()
    if folder_selected:
        folder_path_label.config(text=f"📁 Selected: {folder_selected}", fg="#2ecc71")
        parse_properties(folder_selected)
    else:
        folder_path_label.config(text="⚠️ No folder selected", fg="orange")

def parse_properties(base_path):
    output_text.config(state='normal')
    output_text.delete('1.0', END)
    status_label.config(text="🔄 Scanning folders...", fg="#3498db")

    verticals = os.listdir(base_path)

    for vertical in sorted(verticals):
        vertical_path = os.path.join(base_path, vertical)
        if not os.path.isdir(vertical_path):
            continue

        output_text.insert(END, f"\n📂 Vertical: {vertical}\n", "section")

        subfolders = os.listdir(vertical_path)
        for sub in sorted(subfolders):
            subfolder_path = os.path.join(vertical_path, sub)
            if not os.path.isdir(subfolder_path):
                continue

            property_files = [
                f for f in os.listdir(subfolder_path)
                if f.endswith((".property", ".properties", ".txt", ".json"))
            ]

            for prop_file in sorted(property_files):
                full_path = os.path.join(subfolder_path, prop_file)
                found_keys = []

                try:
                    if prop_file.endswith(".json"):
                        with open(full_path, "r", encoding="utf-8") as f:
                            json_data = json.load(f)
                            for key, value in json_data.items():
                                if key_is_allowed(key):
                                    found_keys.append((key, value))
                    else:
                        with open(full_path, "r", encoding="utf-8") as f:
                            for line in f:
                                line = line.strip()
                                if not line or line.startswith("#"):
                                    continue

                                key, value = None, None
                                if "=" in line:
                                    parts = line.split("=", 1)
                                    if len(parts) == 2:
                                        key, value = parts[0].strip(), parts[1].strip()
                                elif re.match(r'^".*?"\s*:\s*".*?"$', line):
                                    match = re.match(r'^"(.*?)"\s*:\s*"(.*?)"$', line)
                                    if match:
                                        key = match.group(1).strip()
                                        value = match.group(2).strip()

                                if key and key_is_allowed(key):
                                    found_keys.append((key, value))
                except Exception as e:
                    found_keys.append((f"Error reading file {prop_file}", str(e)))

                if found_keys:
                    output_text.insert(END, f"\n📄 {sub}/{prop_file}\n", "file")
                    for key, value in found_keys:
                        output_text.insert(END, f"   🔑 {key} → ", "key")
                        output_text.insert(END, f"{value}\n", "value")

    output_text.config(state='disabled')
    status_label.config(text="✅ Scan complete", fg="#2ecc71")

def search_keyword():
    output_text.tag_remove("search_highlight", "1.0", END)
    keyword = search_entry.get().strip().lower()
    if not keyword:
        return

    start_pos = "1.0"
    while True:
        start_pos = output_text.search(keyword, start_pos, nocase=1, stopindex=END)
        if not start_pos:
            break
        end_pos = f"{start_pos}+{len(keyword)}c"
        output_text.tag_add("search_highlight", start_pos, end_pos)
        start_pos = end_pos

    output_text.tag_config("search_highlight", background="#f1c40f", foreground="#000000")
    status_label.config(text=f"🔍 Searched for: {keyword}", fg="#f1c40f")

# === GUI Setup ===
root = Tk()
root.iconbitmap("your_icon.ico")
root.title("Vertical Property Dashboard")
root.geometry("1400x900")
root.configure(bg="#1e272e")

# Title
Label(root, text="🔍 Vertical Property Scanner", font=("Helvetica", 20, "bold"),
      bg="#2f3640", fg="white", pady=10).pack(fill=X)

# Folder path label
folder_path_label = Label(root, text="Select a folder to begin...", font=("Helvetica", 11),
                          bg="#1e272e", fg="lightgray")
folder_path_label.pack(pady=(5, 0))

# Buttons and search
btn_frame = Frame(root, bg="#1e272e")
btn_frame.pack(pady=10)

Button(btn_frame, text="📁 Browse Folder", command=browse_folder,
       font=("Helvetica", 11, "bold"), bg="#0984e3", fg="white", padx=15, pady=6).pack(side=LEFT, padx=5)

search_entry = Entry(btn_frame, font=("Helvetica", 11), bg="#2d3436", fg="white", insertbackground="white")
search_entry.pack(side=LEFT, padx=5)

Button(btn_frame, text="🔍 Search", command=search_keyword,
       font=("Helvetica", 11, "bold"), bg="#00b894", fg="white", padx=15, pady=6).pack(side=LEFT, padx=5)

# Output area
frame = Frame(root)
frame.pack(fill=BOTH, expand=True, padx=20, pady=10)

scrollbar = Scrollbar(frame)
scrollbar.pack(side=RIGHT, fill=Y)

output_text = Text(frame, wrap="word", yscrollcommand=scrollbar.set,
                   font=("Courier New", 11), bg="#2f3640", fg="#dfe6e9", insertbackground="white", borderwidth=2, relief="solid")
output_text.pack(fill=BOTH, expand=True)
scrollbar.config(command=output_text.yview)

# Tags for styling
output_text.tag_config("section", foreground="#00cec9", font=("Courier New", 12, "bold"))
output_text.tag_config("file", foreground="#74b9ff", font=("Courier New", 11, "bold"))
output_text.tag_config("key", foreground="#a29bfe", font=("Courier New", 11, "bold"))
output_text.tag_config("value", foreground="#dfe6e9", font=("Courier New", 11))

# Status label
status_label = Label(root, text="", font=("Helvetica", 10), bg="#1e272e", fg="gray")
status_label.pack(side=BOTTOM, pady=5)

# Disable editing
output_text.config(state='disabled')

root.mainloop()
